package com.example.librosmined;

import android.app.*;import android.os.*;import android.graphics.Color;import android.graphics.Typeface;import android.graphics.drawable.GradientDrawable;import android.view.*;import android.widget.*;import java.util.*;

public class MainActivity extends Activity {
 LinearLayout root, content; int blue=Color.rgb(21,101,192); ArrayList<String> favorites=new ArrayList<>();
 String[] subjects={"Matemática","Lengua y Literatura","Ciencias Naturales","Inglés","Historia de Nicaragua"};
 @Override public void onCreate(Bundle b){super.onCreate(b); showHome();}
 TextView tv(String s,int sp){TextView t=new TextView(this);t.setText(s);t.setTextSize(sp);t.setTextColor(Color.DKGRAY);t.setPadding(16,10,16,10);return t;}
 TextView title(String s){TextView t=tv(s,22);t.setTextColor(Color.WHITE);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
 GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
 Button btn(String s){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(14);b.setBackground(bg(blue,18));return b;}
 void base(String heading){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(247,248,250));
  LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(8,8,8,8);bar.setBackgroundColor(blue);
  TextView h=title(heading);bar.addView(h,new LinearLayout.LayoutParams(0,64,1));
  TextView search=title("⌕");search.setTextSize(32);bar.addView(search,new LinearLayout.LayoutParams(55,64));
  root.addView(bar); content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(16,12,16,80); ScrollView sv=new ScrollView(this);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
  LinearLayout nav=new LinearLayout(this);nav.setGravity(Gravity.CENTER);nav.setBackgroundColor(Color.WHITE);String[] ns={"⌂\nInicio","◉\nExplorar","♡\nFavoritos","⇩\nDescargas","☰\nMás"};for(String n:ns){TextView x=tv(n,12);x.setGravity(Gravity.CENTER);nav.addView(x,new LinearLayout.LayoutParams(0,62,1));if(n.contains("Inicio"))x.setTextColor(blue);if(n.contains("Explorar"))x.setOnClickListener(v->showExplore());if(n.contains("Favoritos"))x.setOnClickListener(v->showFavorites());}root.addView(nav);setContentView(root);}
 void showHome(){base("Libros MINED\nNicaragua"); TextView intro=tv("Encuentra todos los libros de estudio oficiales del MINED.",17);intro.setPadding(8,18,8,14);content.addView(intro);
  TextView st=tv("Selecciona el nivel",18);st.setTypeface(null,Typeface.BOLD);content.addView(st);
  LinearLayout levels=new LinearLayout(this);levels.setPadding(0,8,0,12);String[] lv={"🎒\nPrimaria\n1° a 6° grado","🎒\nSecundaria\n7° a 11° grado"};for(String s:lv){Button b=new Button(this);b.setText(s);b.setTextSize(15);b.setAllCaps(false);b.setBackground(bg(Color.WHITE,18));b.setOnClickListener(v->showGrades(s.contains("Primaria")));levels.addView(b,new LinearLayout.LayoutParams(0,120,1));}content.addView(levels);
  TextView pop=tv("Materias populares",18);pop.setTypeface(null,Typeface.BOLD);content.addView(pop);for(String s:subjects){Button b=btn(s);b.setAllCaps(false);b.setTextSize(15);b.setOnClickListener(v->showBook(s,"6° grado"));content.addView(b,new LinearLayout.LayoutParams(-1,54));}
  TextView rec=tv("Libros recientes",18);rec.setTypeface(null,Typeface.BOLD);content.addView(rec);for(String s:new String[]{"Matemática — 6° grado","Lengua y Literatura — 8° grado","Ciencias Naturales — 7° grado"}){TextView x=tv("📘  "+s,16);x.setBackground(bg(Color.WHITE,14));x.setPadding(18,18,18,18);x.setOnClickListener(v->showBook(s.split(" — ")[0],s.contains("6")?"6° grado":s.contains("8")?"8° grado":"7° grado"));content.addView(x,new LinearLayout.LayoutParams(-1,65));}}
 void showExplore(){base("Explorar");TextView x=tv("Selecciona el grado",18);x.setTypeface(null,Typeface.BOLD);content.addView(x);showGradeButtons(true);}
 void showGrades(boolean primary){base(primary?"Primaria":"Secundaria");TextView x=tv("Selecciona el grado",18);x.setTypeface(null,Typeface.BOLD);content.addView(x);showGradeButtons(primary);}
 void showGradeButtons(boolean primary){int start=primary?1:7,end=primary?6:11;for(int i=start;i<=end;i++){Button b=btn(i+"° grado     ›");b.setAllCaps(false);int g=i;b.setOnClickListener(v->showSubjects(g));content.addView(b,new LinearLayout.LayoutParams(-1,58));}}
 void showSubjects(int grade){base(grade+"° grado");TextView x=tv("Materias",18);x.setTypeface(null,Typeface.BOLD);content.addView(x);for(String s:subjects){Button b=btn(s+"     ›");b.setAllCaps(false);b.setOnClickListener(v->showBook(s,grade+"° grado"));content.addView(b,new LinearLayout.LayoutParams(-1,58));}}
 void showBook(String subject,String grade){base(subject+" — "+grade);LinearLayout card=new LinearLayout(this);card.setOrientation(LinearLayout.VERTICAL);card.setPadding(18,18,18,18);card.setBackground(bg(Color.WHITE,18));TextView name=tv("📖\n"+subject,23);name.setTypeface(null,Typeface.BOLD);card.addView(name);card.addView(tv("Libro de texto • "+grade+" • MINED Nicaragua\nFormato: PDF",15));Button read=btn("📖  Leer ahora");read.setAllCaps(false);read.setOnClickListener(v->reader(subject,grade));card.addView(read);Button fav=btn("♡  Guardar en favoritos");fav.setAllCaps(false);fav.setOnClickListener(v->{favorites.add(subject+" — "+grade);Toast.makeText(this,"Agregado a favoritos",Toast.LENGTH_SHORT).show();});card.addView(fav);content.addView(card);}
 void reader(String subject,String grade){base(subject+" — "+grade);TextView page=tv("Página 1\n\n"+subject+"\n\nContenido del libro\n\nEsta es la pantalla lectora de la primera versión. Aquí se integrarán los PDF oficiales del MINED cuando estén disponibles y autorizados para distribución.\n\n←  Anterior                         Siguiente  →",18);page.setLineSpacing(10,1.1f);content.addView(page);}
 void showFavorites(){base("Favoritos");if(favorites.isEmpty())content.addView(tv("♡\n\nAún no tienes libros guardados.",18));else for(String s:favorites)content.addView(tv("📕  "+s,16));}
}
